# Hướng dẫn dùng bộ LaTeX báo cáo PharmaCare

## 1. Biên dịch
- **Overleaf (khuyên dùng):** New Project → Upload Project (zip này) → Menu → Compiler = **XeLaTeX** → Recompile. Gõ tiếng Việt, phông chữ TeX Gyre Termes / Latin Modern Mono đã có sẵn trên Overleaf.
- **Máy cá nhân:** cài TeX Live/MiKTeX đầy đủ, rồi `latexmk -xelatex main.tex` (đã có `latexmkrc`).
- Bản nháp hiện **~72 trang** (có tính các khung hình giữ chỗ). Khi thay bằng ảnh thật số trang giữ nguyên hoặc nhiều hơn.

## 2. Cấu trúc
| Tệp / thư mục | Nội dung |
|---|---|
| `info.tex` | **Điền đầu tiên**: tên môn, GVHD, nhóm, thành viên, link GitHub (dùng cho bìa) |
| `main.tex`, `preamble.tex` | Khung tài liệu, phông, kiểu mã nguồn, macro `\TODO`, `\figph` |
| `chapters/01..09-*.tex` | 9 chương; `A-install`, `B-contribution`, `C-source` là phụ lục |
| `chapters/tc-table.tex` | **Sinh tự động** từ `data/TestCases.md` bằng `python3 tools/md2tex_testcases.py` |
| `figures/` | Ảnh chụp màn hình + sơ đồ (đặt đúng tên ở mục 4) |
| `diagrams/*.puml` | Mã PlantUML cho use case, class, 3 sequence (dán vào plantuml.com hoặc VS Code PlantUML, xuất PNG) |
| `code/` | Bản sao các tệp mã dùng cho `\lstinputlisting` (zip phải tự chứa được) |
| `refs.bib` | Tài liệu tham khảo (thêm nguồn mới ở đây) |

## 3. Chế độ nháp / nộp bài
- Trong `preamble.tex`: `\draftmodetrue` hiện chữ đỏ **[TODO: ...]** và khung xám "Chèn hình". Việc còn lại = tìm chữ đỏ.
- Khi nộp đổi thành `\draftmodefalse` → mọi TODO và khung giữ chỗ biến mất. **Kiểm tra lại số trang sau khi đổi** (khung giữ chỗ cũng chiếm chỗ).
- Tìm nhanh phần còn thiếu: tìm `TODO` trong Overleaf (Ctrl+Shift+F).

## 4. Danh sách ảnh cần có (đặt vào `figures/`, định dạng png)
- **Chụp màn hình (làm sau khi build chạy được):** `login`, `dashboard`, `medicines`, `medicines-readonly` (đăng nhập duocsi), `medicine-edit`, `validation`, `categories`, `suppliers`, `receive`, `sales`, `error-dialog` (bán vượt tồn), `invoice-preview`, `invoice-preview-multipage` (hóa đơn ≥ 40 dòng), `invoices`, `alerts`, `revenue`, `test-evidence`, `github-contributors`.
- **Sơ đồ từ `diagrams/*.puml`:** `usecase`, `class-diagram`, `seq-login`, `seq-sale`, `seq-receive`. (Tùy chọn: `erd-ssms`.)
- ERD (hình 4.1) và sơ đồ kiến trúc (hình 5.1) đã vẽ sẵn bằng TikZ.

## 5. Dùng NotebookLM để viết phần còn thiếu (đúng việc, đúng chương)
**Nguyên tắc:** NotebookLM giỏi *lý thuyết và tài liệu môn học* (Chương 2, một phần Chương 1, 3, 9); **không** biết mã nguồn của nhóm. Phần dựa trên mã (Chương 4–6, 8) đã được viết từ code thật — đừng để NotebookLM viết lại.

| Chương / mục | Nguồn | Việc cần làm |
|---|---|---|
| 2.1–2.8 (lý thuyết) | NotebookLM | Hỏi theo mẫu bên dưới, **diễn đạt lại bằng lời nhóm**, thêm ví dụ lấy từ PharmaCare, dán dưới dòng `\TODO` |
| 1.1 (đặt vấn đề), 3.1 (khảo sát) | Nhóm + NotebookLM | Thêm số liệu/nguồn thật hoặc khảo sát thật nếu có |
| 7 (giao diện) | Ảnh chụp | Chụp ảnh, giữ phần mô tả đã có |
| 8.2–8.4 (kết quả test) | **Chạy thật** | Chạy 20 ca, điền Đạt / Không đạt, ảnh minh chứng. Ghi trung thực |
| 9 (kết luận) | Đã viết | Chỉnh cho đúng với kết quả thật |
| Phụ lục B | Nhóm | Phân công + ảnh thống kê GitHub |

**Mẫu câu hỏi cho NotebookLM** (dán nguyên, đổi phần trong `[...]`):
1. `Chỉ dựa trên các nguồn trong notebook, giải thích [ADO.NET và SqlTransaction] cho sinh viên năm nhất CNTT bằng tiếng Việt, 250-350 từ. Cuối câu nào dùng nguồn thì ghi tên nguồn và trang/mục.`
2. `Liệt kê dàn ý (gạch đầu dòng) các ý chính nên có khi trình bày [mô hình MVP trong WinForms], kèm nguồn trong notebook. Chưa viết thành đoạn văn.`
3. `So sánh [MVC, MVP, MVVM] dưới dạng bảng (tiêu chí: ai xử lý sự kiện, mức độ phụ thuộc View, dễ kiểm thử, phù hợp WinForms), có nguồn.`
4. `Cho 2 ví dụ code C# ngắn minh họa [truy vấn tham số hóa so với nối chuỗi], giải thích vì sao cái thứ nhất chống được SQL injection. Chỉ dùng kiến thức có trong nguồn; nếu nguồn không có thì nói rõ là không có.`
5. `Tôi sẽ dán một đoạn văn do nhóm viết; hãy đối chiếu với các nguồn và chỉ ra câu nào sai hoặc không có trong nguồn.` ← dùng để **kiểm tra lại** đoạn đã viết.

**Quy trình mỗi mục:** (1) hỏi dàn ý → (2) hỏi giải thích ngắn có trích nguồn → (3) *tự viết lại* bằng lời nhóm + 1 ví dụ từ PharmaCare → (4) hỏi mẫu số 5 để kiểm tra → (5) thêm nguồn vào `refs.bib` và `\cite{...}`.

**Lưu ý quan trọng**
- Không chép nguyên văn NotebookLM/giáo trình vào báo cáo (đạo văn, và giảng viên dễ nhận ra giọng văn). Luôn diễn đạt lại và trích dẫn.
- Chỉ trích nguồn **có thật**. Nếu NotebookLM nêu một nguồn không có trong notebook, bỏ qua. Mọi mục trong `refs.bib` phải mở ra kiểm tra được.
- Mỗi con số, tên hàm, mã lỗi trong báo cáo phải khớp mã nguồn thật (báo cáo này đã đối chiếu với bản mã đã vá, .NET 10).

## 6. Danh sách kiểm tra trước khi nộp (hạn 23:59:59 ngày 08/11/2026)
- [ ] `info.tex` đã điền; không còn chữ đỏ TODO; đã đổi `\draftmodefalse`.
- [ ] Đã build dự án trong Visual Studio, chạy 20 test case, điền kết quả thật.
- [ ] Đã chụp đủ ảnh, số trang PDF **> 50** (tính cả hình + tài liệu tham khảo).
- [ ] Biên dịch sạch trên Overleaf (XeLaTeX), mở PDF kiểm tra mục lục, danh mục hình/bảng, tham chiếu `??`.
- [ ] Đẩy lên GitHub (public): mã nguồn, README, thư mục `report/` (hoặc `PharmaCare_Report.zip`) và PDF; mỗi thành viên có commit riêng.
- [ ] Nhóm trưởng nộp tại http://submit.thoailt.com/ **trước hạn vài giờ** (đừng đợi phút chót).

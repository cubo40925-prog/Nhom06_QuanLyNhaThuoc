#!/usr/bin/env python3
"""Chuyển bảng test case Markdown (data/TestCases.md) thành bảng longtable LaTeX (chapters/tc-table.tex).
Chạy:  python3 tools/md2tex_testcases.py     (đứng ở thư mục gốc dự án LaTeX)
Sửa test case ở data/TestCases.md (copy từ Docs/TestCases.md của repo) rồi chạy lại để báo cáo luôn khớp."""
import re, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
src = (root / "data" / "TestCases.md").read_text(encoding="utf-8")

SPECIAL = {"\\": r"\textbackslash{}", "{": r"\{", "}": r"\}", "$": r"\$", "&": r"\&", "#": r"\#",
           "_": r"\_", "%": r"\%", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
def esc(t):
    t = "".join(SPECIAL.get(c, c) for c in t)
    return (t.replace("→", r"$\rightarrow$").replace("≤", r"$\leq$").replace("≥", r"$\geq$")
             .replace("✓", r"$\checkmark$"))

def cell(text):
    out, pos = [], 0
    for m in re.finditer(r"`([^`]+)`|\*\*([^*]+)\*\*", text):
        out.append(esc(text[pos:m.start()]))
        out.append(r"\texttt{%s}" % re.sub(r"([a-z])([A-Z])", r"\1\\allowbreak{}\2", esc(m.group(1))) if m.group(1) else r"\textbf{%s}" % esc(m.group(2)))
        pos = m.end()
    out.append(esc(text[pos:]))
    return "".join(out)

rows = []
for line in src.splitlines():
    if re.match(r"\|\s*TC\d+\s*\|", line):
        c = [x.strip() for x in line.strip().strip("|").split("|")]
        rows.append(c[:4] + [c[5] if len(c) > 5 else ""])
head = r"""% TỆP SINH TỰ ĐỘNG bởi tools/md2tex_testcases.py - đừng sửa tay
{\small\setlength{\tabcolsep}{3pt}
\begin{longtable}{@{}>{\raggedright\arraybackslash}p{1.0cm}>{\raggedright\arraybackslash}p{2.2cm}>{\raggedright\arraybackslash}p{4.9cm}>{\raggedright\arraybackslash}p{5.0cm}p{1.2cm}@{}}
\caption{Bảng ca kiểm thử (__N__ ca)}\label{tab:testcases}\\
\toprule \textbf{ID} & \textbf{Chức năng} & \textbf{Thao tác / dữ liệu} & \textbf{Kết quả mong đợi} & \textbf{Kết quả}\\ \midrule
\endfirsthead
\toprule \textbf{ID} & \textbf{Chức năng} & \textbf{Thao tác / dữ liệu} & \textbf{Kết quả mong đợi} & \textbf{Kết quả}\\ \midrule
\endhead
\bottomrule
\endfoot
""".replace("__N__", str(len(rows)))
body = "".join(" & ".join(cell(x) for x in r) + " \\\\ \\midrule\n" for r in rows)
(root / "chapters" / "tc-table.tex").write_text(head + body + "\\end{longtable}}\n", encoding="utf-8")
print(f"OK: {len(rows)} test case -> chapters/tc-table.tex")
